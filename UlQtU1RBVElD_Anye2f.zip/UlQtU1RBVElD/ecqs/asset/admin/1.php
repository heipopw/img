<?php
echo json_encode(array(
  'code'        => 200,
  'msg'         => 'V2.0',
  'data'      => '正常',
));
